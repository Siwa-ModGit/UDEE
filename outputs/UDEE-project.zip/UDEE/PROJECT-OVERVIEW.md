# UDEE — อยู่ดี

A home and condominium rental platform concept for Bangkok, surrounding provinces, Chonburi, and Rayong.

## Current implementation

This snapshot contains the brand starter assets only: an editable SVG logo, JSON color palette, and usage README under assets/brand/udee/. A working website and backend have not been implemented in this repository.

## Planned features

- Natural-language property search with AI.
- Property listings, saved properties, and viewing requests.
- Animated location-guide videos in property details.

## Continue working

Extract this folder, then open it as a local project in the ChatGPT desktop app or Codex. Ask the assistant to inspect the existing assets before making changes. This is a file snapshot; edits do not sync back to the original project automatically.
